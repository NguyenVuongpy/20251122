import os
import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect, QComboBox, QDialog, QTableWidget, QTableWidgetItem,
    QScrollArea
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
# Optional: Excel COM for perfect sheet copy (keeps images & formatting)
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None
from PyQt6 import QtCore, QtGui, QtWidgets
import rc.icons

# Import detectors and CCD model helpers
from detector.hotpixel_detector import HotpixelChecker
from detector.bubble_detector import BubbleCheckerThread
from detector.lshape_detector import LShapeCheckerThread
from detector.ccd_detector import CCDChecker, load_model_config, save_model_config, ModelManagementDialog


class CombinedDetectorController(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    update_current_detector = pyqtSignal(str)  # Signal to update current detector indicator
    finished = pyqtSignal(dict)

    def __init__(self, root_folder, ccd_model_name, ccd_models_config):
        super().__init__()
        self.root_folder = root_folder
        self.ccd_model_name = ccd_model_name
        self.ccd_models_config = ccd_models_config

        self.results = {
            'hotpixel': [],
            'ccd': [],
            'bubble': [],
            'lshape': []
        }

        self._current_det_total = 4  # number of detectors
        self._det_index = 0
        self.combined_path = os.path.join(self.root_folder, "Analysis_Report.xlsx")
        self._summary_initialized = False

    def _forward_log(self, prefix):
        def _inner(message):
            self.update_log.emit(f"[{prefix}] {message}")
        return _inner

    def run(self):
        try:
            # Ensure combined workbook (Summary) exists before running
            self._ensure_combined_workbook()
            # HotPixel
            self._det_index = 0
            self.update_current_detector.emit("🔍 Checking: HotPixel Detector...")
            self.update_log.emit("Starting HotPixel Detector...")
            hot_thread = HotpixelChecker(self.root_folder)
            hot_thread.update_log.connect(self._forward_log("HotPixel"))
            # Progress per detector: 0-25-50-75-100 split
            hot_thread.update_progress.connect(lambda p: self.update_progress.emit(int((self._det_index * 100 / self._current_det_total) + p / self._current_det_total)))
            result_container = []
            hot_thread.finished.connect(lambda folders: result_container.extend(folders))
            hot_thread.run()  # run synchronously inside this controller thread
            self.results['hotpixel'] = list(set(result_container))
            # Append summary only (detectors themselves write sheets)
            self._append_summary_row("HotPixel", self.results['hotpixel'])

            # CCD
            self._det_index = 1
            self.update_current_detector.emit("🔍 Checking: CCD Detector...")
            self.update_log.emit("Starting CCD Detector...")
            ccd_thread = CCDChecker(self.root_folder, self.ccd_model_name, self.ccd_models_config)
            ccd_thread.update_log.connect(self._forward_log("CCD"))
            ccd_thread.update_progress.connect(lambda p: self.update_progress.emit(int((self._det_index * 100 / self._current_det_total) + p / self._current_det_total)))
            ccd_result_container = []
            ccd_thread.finished.connect(lambda folders: ccd_result_container.extend(folders))
            ccd_thread.run()
            self.results['ccd'] = list(set(ccd_result_container))
            self._append_summary_row("CCD", self.results['ccd'])

            # Bubble
            self._det_index = 2
            self.update_current_detector.emit("🔍 Checking: Bubble Detector...")
            self.update_log.emit("Starting Bubble Detector...")
            bubble_thread = BubbleCheckerThread(self.root_folder)
            bubble_thread.update_log.connect(self._forward_log("Bubble"))
            bubble_thread.update_progress.connect(lambda p: self.update_progress.emit(int((self._det_index * 100 / self._current_det_total) + p / self._current_det_total)))
            bubble_result_container = []
            bubble_thread.finished.connect(lambda folders: bubble_result_container.extend(folders))
            bubble_thread.run()
            self.results['bubble'] = list(set(bubble_result_container))
            self._append_summary_row("Bubble", self.results['bubble'])

            # LShape
            self._det_index = 3
            self.update_current_detector.emit("🔍 Checking: LShape Detector...")
            self.update_log.emit("Starting LShape Detector...")
            lshape_thread = LShapeCheckerThread(self.root_folder)
            lshape_thread.update_log.connect(self._forward_log("LShape"))
            lshape_thread.update_progress.connect(lambda p: self.update_progress.emit(int((self._det_index * 100 / self._current_det_total) + p / self._current_det_total)))
            lshape_result_container = []
            lshape_thread.finished.connect(lambda folders: lshape_result_container.extend(folders))
            lshape_thread.run()
            self.results['lshape'] = list(set(lshape_result_container))
            self._append_summary_row("LShape", self.results['lshape'])

            self.update_current_detector.emit("✅ All checks completed!")
            self.update_progress.emit(100)
            self.finished.emit(self.results)
        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit(self.results)

    def _ensure_combined_workbook(self):
        if self._summary_initialized and os.path.exists(self.combined_path):
            return
        # Load existing combined workbook if present; else create new
        from openpyxl import load_workbook as _lw
        if os.path.exists(self.combined_path):
            wb = _lw(self.combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                # Clear ALL rows including headers to start fresh
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary")
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"
        # Always add headers (sheet is now empty)
        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60
        wb.save(self.combined_path)
        self._summary_initialized = True

    def _append_summary_row(self, name, folders):
        try:
            from openpyxl import load_workbook as _lw
            wb = _lw(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            # Calculate total cameras (folders) checked
            total_cameras = 0
            if os.path.exists(self.root_folder):
                total_cameras = len([f for f in os.listdir(self.root_folder) if os.path.isdir(os.path.join(self.root_folder, f)) 
                                    and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", 
                                                  "Bubble_Analysis_Results", "LShape_Analysis_Results"]])
            # Format: "error_count / total_cameras"
            camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
            ws.append([name, camera_count_text, "\n".join(folders_sorted)])
            row = ws.max_row
            for col in range(1, 4):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            wb.save(self.combined_path)
            self.update_log.emit(f"Summary updated: {name} -> {error_count} / {total_cameras} cameras")
        except Exception as e:
            self.update_log.emit(f"Warning: could not update Summary for {name}: {e}")

class SummaryDialog(QDialog):
    def __init__(self, parent, table_rows, open_cb):
        super().__init__(parent)
        self.setWindowTitle("Image Analysis Results")
        self.setModal(True)
        self.resize(800, 700)
        
        # Main layout with margins
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Header with gradient
        header = QWidget()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 10px;
            }
        """)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 0, 20, 0)
        
        title = QLabel("📊 Image Analysis Results")
        title.setStyleSheet("color: white; font-weight: bold;")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        hl.addWidget(title)
        hl.addStretch()
        
        self.btn_open = QPushButton("📁 Open Report Excel")
        self.btn_open.setStyleSheet("""
            QPushButton {
                background: #fff;
                color: #2c3e50;
                border: 2px solid #fff;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background: #eaf2fb;
                border-color: #eaf2fb;
            }
            QPushButton:pressed {
                background: #d0e0f0;
            }
        """)
        self.btn_open.clicked.connect(open_cb)
        hl.addWidget(self.btn_open)
        layout.addWidget(header)

        # Scrollable table container
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: #f0f0f0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #3498db;
                border-radius: 6px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #2980b9;
            }
        """)
        
        # Table widget
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Detector", "Total Camera", "Camera List"])
        self.table.setStyleSheet("""
            QTableWidget {
                background: #ffffff;
                border: 2px solid #e0e0e0;
                border-radius: 10px;
                gridline-color: #e8e8e8;
                font-size: 12px;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f0f0f0;
            }
            QTableWidget::item:selected {
                background: #e3f2fd;
                color: #1976d2;
            }
            QHeaderView::section {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #f5f5f5, stop:1 #e8e8e8);
                color: #2c3e50;
                font-weight: bold;
                font-size: 13px;
                padding: 10px;
                border: none;
                border-bottom: 2px solid #3498db;
            }
        """)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        
        # Calculate error ratios for color scaling
        error_ratios = []
        for row in table_rows:
            if len(row) >= 5:
                error_count = row[3]
                total_count = row[4]
                if total_count > 0:
                    ratio = error_count / total_count
                    error_ratios.append(ratio)
                else:
                    error_ratios.append(0.0)
        
        # Find min and max for color scaling (exclude 0 if you want, but here we include it)
        min_ratio = min(error_ratios) if error_ratios else 0.0
        max_ratio = max(error_ratios) if error_ratios else 1.0
        
        # Fill rows with data and apply color scaling
        for i, row in enumerate(table_rows):
            r = self.table.rowCount()
            self.table.insertRow(r)
            for c, val in enumerate(row[:3]):  # Only take first 3 columns for display
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if c == 0:  # Detector name
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    item.setForeground(QColor("#2c3e50"))
                elif c == 1:  # Total Camera - apply color scale
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    # Apply red-white color scale based on error ratio
                    if len(row) >= 5 and i < len(error_ratios):
                        ratio = error_ratios[i]
                        if max_ratio > min_ratio:  # Avoid division by zero
                            # Normalize ratio to 0-1 range
                            normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                        else:
                            normalized = 0.0
                        
                        # Red-white color scale: higher ratio = more red
                        red = int(255 * normalized)
                        green = int(255 * (1 - normalized))
                        blue = int(255 * (1 - normalized))
                        
                        # Ensure colors are within bounds
                        red = min(255, max(200, red))  # Keep some red tint even at minimum
                        green = min(255, max(200, green))
                        blue = min(255, max(200, blue))
                        
                        bg_color = QColor(red, green, blue)
                        # Choose text color based on background brightness
                        brightness = red * 0.299 + green * 0.587 + blue * 0.114
                        text_color = QColor("#000000") if brightness > 180 else QColor("#FFFFFF")
                        
                        item.setBackground(bg_color)
                        item.setForeground(text_color)
                else:  # Camera List
                    item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
                self.table.setItem(r, c, item)
        
        # Set column widths
        self.table.setColumnWidth(0, 200)  # Detector
        self.table.setColumnWidth(1, 150)  # Total Camera
        self.table.setWordWrap(True)
        self.table.resizeRowsToContents()
        
        scroll_area.setWidget(self.table)
        layout.addWidget(scroll_area)
        
        # Footer buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_close = QPushButton("✕ Close")
        btn_close.setStyleSheet("""
            QPushButton {
                background: #3498db;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 24px;
                font-weight: bold;
                font-size: 13px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #2980b9;
            }
            QPushButton:pressed {
                background: #21618c;
            }
        """)
        btn_close.clicked.connect(self.accept)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent
        self.setWindowTitle("Automatic image analysis tool")
        self.resize(700, 800)
        self.setWindowIcon(QIcon(":/icons/image_analysis.png"))

        # UI theme
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        # Prevent app from quitting unexpectedly if all windows accidentally close
        app = QApplication.instance()
        if app is not None:
            try:
                app.setQuitOnLastWindowClosed(False)
            except Exception:
                pass

        self.selected_folder = None
        self.analysis_output_folder = None
        self.models_config = load_model_config()

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(90)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        icon = QtGui.QIcon(":/icons/image_analysis.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        header_layout.addWidget(icon_button)

        # Text container
        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Automatic image analysis tool")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 22, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QtWidgets.QLabel("HotPixel, CCD, Bubble, LShape Camera defect Checker")
        subtitle_label.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)

        header_layout.addStretch()

        # Settings button (match CCD UI)
        self.btn_manage_models = QtWidgets.QPushButton("")
        self.btn_manage_models.setIcon(QIcon(":/icons/setting.png"))
        self.btn_manage_models.setIconSize(QSize(50, 50))
        self.btn_manage_models.setFixedSize(60, 60)
        self.btn_manage_models.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_manage_models.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.2);
                border: none;
                border-radius: 20px;
                padding: 5px;
                color: white;
            }
            QPushButton:hover { background-color: rgba(255, 255, 255, 0.3); }
            QPushButton:pressed { background-color: rgba(255, 255, 255, 0.4); }
        """)
        settings_shadow = QtWidgets.QGraphicsDropShadowEffect()
        settings_shadow.setBlurRadius(8)
        settings_shadow.setXOffset(1)
        settings_shadow.setYOffset(1)
        settings_shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self.btn_manage_models.setGraphicsEffect(settings_shadow)
        self.btn_manage_models.clicked.connect(self.manage_models)
        header_layout.addWidget(self.btn_manage_models)
        main_layout.addWidget(header_container)

        # Controls
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)

        # CCD model selection (exactly like CCD UI)
        model_label = QLabel("Select Model:")
        model_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        model_label.setStyleSheet("color: #2c3e50;")
        controls_layout.addWidget(model_label)

        self.combo_model_selection = QtWidgets.QComboBox()
        self.combo_model_selection.setStyleSheet("""
            QComboBox {
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 14px;
                color: #2c3e50;
                background-color: white;
                min-width: 100px;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 25px;
                border-left-width: 1px;
                border-left-color: #3498db;
                border-left-style: solid;
                border-top-right-radius: 8px;
                border-bottom-right-radius: 8px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/down_arrow.png);
                width: 15px;
                height: 15px;
            }
            QComboBox:hover { border-color: #2980b9; }
        """)
        controls_layout.addWidget(self.combo_model_selection)

        # Init models config like CCD
        self.combo_model_selection.blockSignals(True)
        self.combo_model_selection.currentTextChanged.connect(self.on_model_selected)
        initial_config = load_model_config()
        self.models_config = initial_config["models"]
        self.last_selected_model = initial_config["last_selected_model"]
        if not self.models_config:
            self.models_config = {"D965": 721, "D914": 699}
            self.last_selected_model = "D965"
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
        self._load_models_to_combobox()
        if self.last_selected_model and self.last_selected_model in self.models_config:
            self.combo_model_selection.setCurrentText(self.last_selected_model)
            self.selected_model = self.last_selected_model
        elif self.models_config:
            self.selected_model = next(iter(self.models_config))
            self.combo_model_selection.setCurrentText(self.selected_model)
        else:
            self.selected_model = None
        self.combo_model_selection.blockSignals(False)
        if self.selected_model:
            self.on_model_selected()

        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        # Select folder button (after model like CCD)
        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet(self._button_style())
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        # Separator
        separator1 = QLabel("|")
        separator1.setStyleSheet("color: #3498db; font-size: 20px;")
        separator1.setFixedHeight(40)
        controls_layout.addWidget(separator1)

        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet(self._button_style())
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        main_layout.addWidget(controls_container)

        # Progress
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(12)
        
        # Current detector indicator
        self.current_detector_label = QLabel("Ready to start...")
        self.current_detector_label.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        self.current_detector_label.setStyleSheet("""
            QLabel {
                color: #2c3e50;
                background: #f0f2f5;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 10px 15px;
                text-align: center;
            }
        """)
        self.current_detector_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        progress_layout.addWidget(self.current_detector_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background: #3498db;
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)
        main_layout.addWidget(progress_container)

        # Log
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())
        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)
        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)
        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()
        log_layout.addWidget(log_header)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)
        main_layout.addWidget(log_container)

        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # State
        self.controller = None
        self.summary_results = None

    def _button_style(self):
        return """
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def _load_models_to_combobox(self):
        try:
            self.combo_model_selection.clear()
            for model_name in self.models_config.keys():
                self.combo_model_selection.addItem(model_name)
        except Exception:
            pass

    def on_model_selected(self):
        try:
            self.selected_model = self.combo_model_selection.currentText()
            self.last_selected_model = self.selected_model
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
            if hasattr(self, 'log_text'):
                self.log_text.append(f"Selected model: {self.selected_model}")
        except Exception:
            pass

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self,
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = self.selected_folder
            self.btn_start.setEnabled(True)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if not self.selected_folder:
            QMessageBox.warning(self, "Warning", "Please select a folder first!")
            return
        # Save last selected model
        current_model = getattr(self, 'selected_model', None) or (self.combo_model_selection.currentText() if hasattr(self, 'combo_model_selection') else None)
        if current_model:
            save_model_config({"models": self.models_config, "last_selected_model": current_model})

        self.controller = CombinedDetectorController(self.selected_folder, current_model, self.models_config)
        self.controller.update_progress.connect(self.update_progress)
        self.controller.update_log.connect(self.update_log)
        self.controller.update_current_detector.connect(self.update_current_detector_label)
        self.controller.finished.connect(self.on_finished)
        self.controller.start()

        self.btn_start.setEnabled(False)
        self.current_detector_label.setText("🔄 Initializing...")
        self.current_detector_label.setStyleSheet("""
            QLabel {
                color: #fff;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3498db, stop:1 #2980b9);
                border: 2px solid #2980b9;
                border-radius: 8px;
                padding: 10px 15px;
                text-align: center;
            }
        """)
        self.statusBar().showMessage("Running detectors...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_current_detector_label(self, text):
        """Update the current detector indicator with animated style"""
        self.current_detector_label.setText(text)
        if "✅" in text:
            # Completed state
            self.current_detector_label.setStyleSheet("""
                QLabel {
                    color: #fff;
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #27ae60, stop:1 #229954);
                    border: 2px solid #229954;
                    border-radius: 8px;
                    padding: 10px 15px;
                    text-align: center;
                }
            """)
        elif "🔍" in text:
            # Checking state - animated blue gradient
            self.current_detector_label.setStyleSheet("""
                QLabel {
                    color: #fff;
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3498db, stop:1 #2980b9);
                    border: 2px solid #2980b9;
                    border-radius: 8px;
                    padding: 10px 15px;
                    text-align: center;
                }
            """)
        else:
            # Default state
            self.current_detector_label.setStyleSheet("""
                QLabel {
                    color: #2c3e50;
                    background: #f0f2f5;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                    padding: 10px 15px;
                    text-align: center;
                }
            """)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, results):
        self.btn_start.setEnabled(True)
        self.statusBar().showMessage("Check completed")
        self.summary_results = results
        # Reset detector label after a delay
        self.current_detector_label.setText("✅ All checks completed!")
        self.current_detector_label.setStyleSheet("""
            QLabel {
                color: #fff;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #27ae60, stop:1 #229954);
                border: 2px solid #229954;
                border-radius: 8px;
                padding: 10px 15px;
                text-align: center;
            }
        """)

        # Create combined Excel report (summary + links to full reports)
        combined_path = None
        table_rows = []
        try:
            combined_path, table_rows = self._create_combined_excel_report(results)
        except Exception as e:
            self.log_text.append(f"Error creating combined report: {e}")

        # Custom summary dialog (modal) showing same content as Summary sheet
        def open_combined():
            if not combined_path or not os.path.exists(combined_path):
                QMessageBox.warning(self, "Error", "Combined report is not available.")
                return
            try:
                os.startfile(combined_path)
            except Exception as ee:
                QMessageBox.warning(self, "Error", f"Could not open Excel file: {ee}")

        self.summary_dialog = SummaryDialog(self, table_rows, open_combined)
        self.summary_dialog.exec()

    def _create_combined_excel_report(self, results):
        root = self.selected_folder
        if not root:
            return None, []
        # Open existing Analysis_Report if present to preserve detector sheets
        from openpyxl import load_workbook as _lw
        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        if os.path.exists(combined_path):
            wb = _lw(combined_path)
            # Get or create Summary sheet
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                # Clear ALL rows including headers to start fresh
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary", 0)
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"

        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

        # Add headers (row 1)
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60

        # Calculate total cameras (folders) checked
        total_cameras = 0
        if os.path.exists(root):
            total_cameras = len([f for f in os.listdir(root) if os.path.isdir(os.path.join(root, f)) 
                                and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", 
                                              "Bubble_Analysis_Results", "LShape_Analysis_Results"]])

        table_rows = []
        error_ratios = []

        def add_row(name, folders):
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            # Format: "error_count / total_cameras"
            camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
            ws.append([name, camera_count_text, "\n".join(folders_sorted)])
            row = ws.max_row
            
            # Calculate error ratio for color scaling
            if total_cameras > 0:
                error_ratio = error_count / total_cameras
            else:
                error_ratio = 0.0
            error_ratios.append(error_ratio)
            
            # Apply formatting to all cells in the row
            for col in range(1, 4):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            
            # For table_rows: use "\n" instead of ", " for camera list
            camera_list_text = "\n".join(folders_sorted) if folders_sorted else ""
            table_rows.append([name, camera_count_text, camera_list_text, error_count, total_cameras])

        add_row("HotPixel Checking", results.get('hotpixel', []))
        add_row("CCD Checking", results.get('ccd', []))
        add_row("Bubble Checking", results.get('bubble', []))
        add_row("LShape", results.get('lshape', []))

        # Apply color scaling to Total Camera column (column B)
        if error_ratios:
            min_ratio = min(error_ratios)
            max_ratio = max(error_ratios)
            
            for i, ratio in enumerate(error_ratios, start=2):  # Start from row 2 (after header)
                if max_ratio > min_ratio:  # Avoid division by zero
                    normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                else:
                    normalized = 0.0
                
                # Red-white color scale: higher ratio = more red
                red = int(255 * normalized)
                green = int(255 * (1 - normalized))
                blue = int(255 * (1 - normalized))
                
                # Ensure colors are within bounds and create nice gradient
                red = min(255, max(200, red))
                green = min(255, max(200, green))
                blue = min(255, max(200, blue))
                
                fill_color = PatternFill(start_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       end_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       fill_type="solid")
                
                # Apply to Total Camera cell (column B)
                total_camera_cell = ws.cell(row=i, column=2)
                total_camera_cell.fill = fill_color
                
                # Choose text color based on background brightness
                brightness = red * 0.299 + green * 0.587 + blue * 0.114
                if brightness > 180:
                    total_camera_cell.font = Font(bold=True, color="000000")
                else:
                    total_camera_cell.font = Font(bold=True, color="FFFFFF")

        # Save combined without touching detector sheets
        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        wb.save(combined_path)
        self.log_text.append(f"Combined report saved: {combined_path}")
        return combined_path, table_rows

    def _try_copy_report(self, src_path, dest_wb, expected_sheet_name):
        # Deprecated: detectors now write directly to AllInOne_Report.xlsx
        return

    def _try_merge_reports_with_excel_com(self, combined_path, src_list):
        # Deprecated: skip COM merge; detectors write directly
        return

    def closeEvent(self, event):
        if self.main_app_window:
            self.main_app_window.setEnabled(True)
            self.main_app_window.remove_blur_effect()
        super().closeEvent(event)

    def manage_models(self):
        dialog = ModelManagementDialog(self.models_config.copy(), self)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            updated = load_model_config()
            self.models_config = updated.get("models", {})
            last = updated.get("last_selected_model")
            self.combo_model_selection.clear()
            self.combo_model_selection.addItems(list(self.models_config.keys()))
            if last and last in self.models_config:
                self.combo_model_selection.setCurrentText(last)
                self.selected_model = last
            elif self.models_config:
                self.combo_model_selection.setCurrentIndex(0)
                self.selected_model = self.combo_model_selection.currentText()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())